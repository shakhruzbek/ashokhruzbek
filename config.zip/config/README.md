The app uses only the company with the id=1 so DO NOT DELETE THE EXISTING COMPANY. Otherwise you will have to change the code

Admin panle credentials (if you want, you can create another one too):
username: admin
password: TheWold2024
